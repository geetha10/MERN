import logo from './logo.svg';
import './App.css';
import UserForm from './Components/UserForm';
import MoreForms from './Components/MoreForms';
import MoreForms2 from './Components/moreForms2';


function App() {
  return (
    <div className="App">
      {/* <UserForm /> */}
      {/* <MoreForms/> */}
      <MoreForms2/>
    </div>
  );
}

export default App;
